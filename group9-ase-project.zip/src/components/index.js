export { default as Navigation } from "./Navigation";
export { default as Home } from "./Home";
export { default as NQueens } from "./NQueensUI";
export { default as Polysphere } from "./PolysphereUI";
export { default as PolyPyramid } from "./PolyPyramidUI";